function A = pos(A)
A(A<0)=0;
end