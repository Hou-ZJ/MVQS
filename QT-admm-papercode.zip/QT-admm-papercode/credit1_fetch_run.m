clc;
clear;
namelist = dir('./credit/credit1/*.mat');
save_path = './results/credit1/';
for i = 1:length(namelist)
    data_path=strcat('./credit/credit1/',namelist(i).name);%data所在目录
    string = namelist(i).name;
    data_num = string(1:end-4);%识别并提取string中的编号
    [result] = mvlinex_corel_run(data_path,save_path,data_num);
    resultarr(i).name = data_num;
    resultarr(i).output = result;
end