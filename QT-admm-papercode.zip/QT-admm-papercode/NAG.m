function [ksiA,iter2,grad]=NAG(Ka,Y,Alp,ksiA,a,C1,pi1,pi3,u1,u3,sig1,sig3,maxiter2,r,eta,tol2)
%[ w , b ] = nesterovlinexsvm( X, Y , a , c )
[n,n1] = size(ksiA);
vel = zeros(n,1);
for iter2 = 1:maxiter2
    eta=eta/iter2;
    %eta = eta*exp(-0.01*iter2)
    ksiA_pre = ksiA-r*vel;
    grad=a*C1*Y.*(exp(a*Y.*ksiA_pre)-1)+u1+u3+sig1*(ksiA_pre+Y.*(Ka*Alp)-1-pi1)+sig3*(ksiA_pre-pi3);
    vel = r*vel + eta*grad;
    ksiA=ksiA-vel;
    
%         f(iter2)=1/m*sum(exp(a*D*ksi)-a*D*ksi-ones(m,1))+sigma/2*(norm((D*A*w+ksi-ones(m,1)*rho-pi_1),2)^2+norm((ksi-pi_2),2)^2);%如果不生成后面的图的话可以不要这行命令
    % t=t+1;
    %stopCond
    stopCond = max(abs(grad));
    %stopCond = norm(grad);
    if (iter2> 10) &&  (stopCond < tol2)
        disp(' !!!stopped by NAG termination rule!!! ');
        break;
    end
end
% 查看梯度下降是否收敛
% figure(1),clf
% step = 1;
% plot(1:step:100,f(1:step:100));

end