function [max_acc,max_gmean,max_fscore,max_auc,max_prec,max_reca,max_spec,search_save]=search_admm(data,errorsave,datanum)

    
%% 测试网格部分
%     [A,C1,C2,C,RBF,THETA] = deal(0.5,10,10, 0 ,1, 10 );
%     RHO = 1;

%% 初始网格部分
    A = [0.1,0.5,1];
    C1 = [0.1,1,10];
    C2 = [0.1,1,10];
    C = [0.1,1,10];
    RHO = [1];%未用到，为了减少循环框架的修改就随便赋一个值
    RBF = [0.1,1,10];
    THETA = [0.1,1,10];


    
%% 不等约束转等式约束后的系数
    [TAU,ETA] = deal(1.618,0.01);
    SIGMA=[0.0038];
%     SIGMA = [3.8*1e-5];%较小
    TOL = [1e-3];%截停条件需要调小，10^-3 to 10^-6


    [max_acc.value,max_gmean.value,max_fscore.value,max_auc.value,max_prec.value,max_reca.value,max_spec.value] = deal(0);
    [max_acc.std,max_gmean.std,max_fscore.std,max_auc.std,max_prec.std,max_reca.std,max_spec.std] = deal(0);
    [max_acc.id,max_gmean.id,max_fscore.id,max_auc.id,max_prec.id,max_reca.id,max_spec.id] = deal(0);
    search_save = [];
    
    tic;
    for i = 1:numel(A)
        para.a = A(i);
        for i = 1:numel(C1)
            para.c1 = C1(i);
            for i = 1:numel(C2)
                para.c2 = C2(i);
                for i = 1:numel(C)
                    para.c3 = C(i);
                    for i = 1:numel(RHO)
                        para.rho = RHO(i);
                        for rbf = RBF
                            
                            for sig = SIGMA
                                for tau = TAU
                                    for tol = TOL
                                        for eta = ETA
                                            for theta = THETA
                                                
                                                %赋值
                                                para.b=para.a;
                                                [sigtau.sig1,sigtau.sig2,sigtau.sig3,sigtau.sig4] = deal(sig);
%                                                 sigtau.sig1 = 1e-10;sigtau.sig3 = 1e-10;sigtau.sig2 = 1e-10;sigtau.sig4 = 1e-10;
                                                [sigtau.tau1,sigtau.tau2] = deal(tau);
                                                %赋值!!!
                                                [stop.iter1,stop.iter2,stop.tol,stop.tol2] = deal(800,500,tol,0.001);%admm最大迭代次数iter1调大
                                                [nag.eta,nag.r] = deal(eta);
                                                %参数储存
                                                parameter = [para.a,para.b,para.c1,para.c2,para.c3,para.rho,rbf,theta];
                                                para4loss = [sig,tau,tol,eta];
                                                dlmwrite(errorsave,[parameter,para4loss],'delimiter',',','-append');
                                                try
                                                    [max_view_acc,max_view_gmean,max_view_fscore,max_view_auc,max_view_prec,max_view_reca,max_view_spec] = Crossvalidation(data,rbf,para,sigtau,stop,nag,theta,datanum);
                                                    search_save_temp = [parameter,para4loss,...
                                                        max_view_acc.value, max_view_acc.id, max_view_acc.std,...
                                                        max_view_gmean.value, max_view_gmean.id, max_view_gmean.std,...
                                                        max_view_fscore.value, max_view_fscore.id, max_view_fscore.std,...
                                                        max_view_auc.value, max_view_auc.id, max_view_auc.std,...
                                                        max_view_prec.value, max_view_prec.id, max_view_prec.std,...
                                                        max_view_reca.value, max_view_reca.id, max_view_reca.std,...
                                                        max_view_spec.value, max_view_spec.id, max_view_spec.std];
                                                    search_save = [search_save;search_save_temp];
                                                catch
                                                    'try_catch errors happen'
                                                    para
                                                    dlmwrite(errorsave,[parameter,para4loss,zeros(1,2)],'delimiter',',','-append');%全为0的哪一行上面为出错参数
                                                    [max_view_acc.value,max_view_gmean.value,max_view_fscore.value,max_view_auc.value,max_view_prec.value,max_view_reca.value,max_view_spec.value] = deal(0);
                                                end
                                                
                                                for search_type = 0:4
                                                    if search_type == 0%acc
                                                        if max_view_acc.value>max_acc.value
                                                            max_acc.value = max_view_acc.value;
                                                            max_acc.std = max_view_acc.std;
                                                            max_acc.id = max_view_acc.id;
                                                        end
                                                    elseif search_type == 1%gmean
                                                        if max_view_gmean.value>max_gmean.value
                                                            max_gmean.value = max_view_gmean.value;
                                                            max_gmean.std = max_view_gmean.std;
                                                            max_gmean.id = max_view_gmean.id;
                                                            max_reca.value = max_view_reca.value;
                                                            max_reca.std = max_view_reca.std;
                                                            max_reca.id = max_view_reca.id;
                                                            max_spec.value = max_view_spec.value;
                                                            max_spec.std = max_view_spec.std;
                                                            max_spec.id = max_view_spec.id;
                                                        end
                                                    elseif search_type == 2%fscore
                                                        if max_view_fscore.value>max_fscore.value
                                                            max_fscore.value = max_view_fscore.value;
                                                            max_fscore.std = max_view_fscore.std;
                                                            max_fscore.id = max_view_fscore.id;
                                                        end
                                                    elseif search_type == 3%auc
                                                        if max_view_auc.value>max_auc.value
                                                            max_auc.value = max_view_auc.value;
                                                            max_auc.std = max_view_auc.std;
                                                            max_auc.id = max_view_auc.id;
                                                        end
                                                    elseif search_type == 4%precision
                                                        if max_view_prec.value>max_prec.value
                                                            max_prec.value = max_view_prec.value;
                                                            max_prec.std = max_view_prec.std;
                                                            max_prec.id = max_view_prec.id;
                                                        end
                                                    end
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
    toc;
end

%                                                     elseif search_type == 5%recall
%                                                         if max_view_reca.value>max_reca.value
%                                                             max_reca.value = max_view_reca.value;
%                                                             max_reca.std = max_view_reca.std;
%                                                             max_reca.id = max_view_reca.id;
%                                                         end
%                                                     elseif search_type == 6%sepcificity
%                                                         if max_view_spec.value>max_spec.value
%                                                             max_spec.value = max_view_spec.value;
%                                                             max_spec.std = max_view_spec.std;
%                                                             max_spec.id = max_view_spec.id;